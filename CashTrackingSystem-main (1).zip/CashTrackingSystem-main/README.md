# CashTrackingSystem
Year 4 project - Development of Cash tracking system for NGOs in Malawi
